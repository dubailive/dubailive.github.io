
 //Scripts by JunesiPhone, mod by J3T, mod by dubs

var twentyfour = false;
var padzero = true;
var refresh = 5000;


var weathercode = 'KEXX0009';
var celsius = true;
var gpsswitch = false; //must use widget weather xml if set to true
var refreshrate = 10;


var language = "en"; // en, cz, it, sp, de, fr, zh 
